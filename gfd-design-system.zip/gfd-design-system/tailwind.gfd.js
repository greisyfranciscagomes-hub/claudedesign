// Tokens GFD para Tailwind CSS
module.exports = {
  "theme": {
    "extend": {
      "colors": {
        "gfd-superficie": {"rosa-claro":"#FBD1F4","azul-claro":"#C2E2FA","verde-claro":"#CDFFC3","nevoa":"#F3F3F3","branco":"#FFFFFF"},
        "gfd-verde-2": {"900":"#0E4132","800":"#16624B","700":"#1D8264","500":"#24A37D","300":"#5BBA9E","200":"#92D1BE","100":"#C8E8DF"},
        "gfd-tinta": "#0B0B0B",
        "gfd-etapa": "#24A37D",
        "gfd": {
          "verde-raiz": {
            "900": "#061C10",
            "800": "#082B18",
            "700": "#0B3920",
            "500": "#0E4728",
            "300": "#4A755E",
            "200": "#87A394",
            "100": "#C3D1C9"
          },
          "verde-pulso": {
            "900": "#156605",
            "800": "#209908",
            "700": "#2ACC0A",
            "500": "#35FF0D",
            "300": "#68FF4A",
            "200": "#9AFF86",
            "100": "#CDFFC3"
          },
          "azul-cursor": {
            "900": "#05385D",
            "800": "#07548C",
            "700": "#0A70BA",
            "500": "#0C8CE9",
            "300": "#49A9EF",
            "200": "#86C6F4",
            "100": "#C2E2FA"
          },
          "rosa": {
            "900": "#5F1C54",
            "800": "#8F2A7F",
            "700": "#BE38A9",
            "500": "#EE46D3",
            "300": "#F274DE",
            "200": "#F7A3E9",
            "100": "#FBD1F4"
          },
          "papel-de-algodao": {
            "900": "#66655F",
            "800": "#99978F",
            "700": "#CCCABE",
            "500": "#FFFCEE",
            "300": "#FFFDF4",
            "200": "#FFFEF9",
            "100": "#FFFFFF"
          },
          "grafite": {
            "900": "#0E0E0E",
            "800": "#161616",
            "700": "#1D1D1D",
            "500": "#242424",
            "300": "#5B5B5B",
            "200": "#929292",
            "100": "#C8C8C8"
          }
        }
      },
      "spacing": {
        "gfd-2xs": "4px",
        "gfd-xs": "8px",
        "gfd-sm": "12px",
        "gfd-md": "16px",
        "gfd-lg": "24px",
        "gfd-xl": "32px",
        "gfd-2xl": "48px",
        "gfd-3xl": "64px",
        "gfd-4xl": "90px"
      },
      "borderRadius": {
        "gfd-xs": "4px",
        "gfd-sm": "6px",
        "gfd-md": "8px",
        "gfd-lg": "16px",
        "gfd-xl": "24px",
        "gfd-pill": "999px"
      },
      "boxShadow": {
        "gfd-sm": "0 2px 6px rgba(36,36,36,0.10)",
        "gfd-md": "0 6px 18px rgba(36,36,36,0.08)",
        "gfd-lg": "0 16px 40px rgba(36,36,36,0.12)",
        "gfd-3d": "0 16px 32px rgba(36,36,36,0.22), 0 4px 5px rgba(36,36,36,0.25)",
        "gfd-brilho-neon": "0 0 45px rgba(53,255,13,0.55)"
      },
      "fontFamily": {
        "gfd-titulo": [
          "'Poppins', sans-serif"
        ],
        "gfd-enfase": [
          "'Instrument Serif', serif"
        ],
        "gfd-texto": [
          "'Poppins', sans-serif"
        ],
        "gfd-mono": [
          "'Space Mono', monospace"
        ]
      }
    }
  }
};
