# GFD Design System · Grey Frame Design

Componentes, tokens e logos da identidade visual da **Grey Frame Design** (branding e marketing médico · @greisyjordao · @gfd.mkt).
É o espelho em código da página **🧩 Design System GFD** do Figma.

> Abra o `index.html` no navegador para ver todos os componentes.

## Estrutura

```
gfd-design-system/
├── index.html            ← catálogo visual de todos os componentes
├── tokens.json           ← fonte da verdade (formato W3C Design Tokens)
├── tokens.css            ← variáveis CSS (--gfd-…)
├── tailwind.gfd.js       ← tema para Tailwind CSS
├── css/components.css    ← componentes em CSS puro (classes .gfd-…)
├── react/gfd-components.jsx ← os mesmos componentes em React
└── logos/                ← logos em SVG (principal, redução, compacta, favicon, mono)
```

## Como usar

### HTML / CSS
```html
<link rel="stylesheet" href="tokens.css">
<link rel="stylesheet" href="css/components.css">

<h2 class="gfd-titulo">Autoridade não se <em>posta</em>.</h2>
<span class="gfd-tag gfd-tag--neon">mkt médico</span>
<a class="gfd-botao" href="#">Fale comigo · link na bio →</a>
```

### React
```jsx
import "./tokens.css";
import "./css/components.css";
import { Titulo, Tag, Botao, MolduraPost, Tecla, CardPreco } from "./react/gfd-components";

<MolduraPost modo="claro" numero={1}>
  <Titulo texto="Autoridade não se *posta*." />
</MolduraPost>
```
No `Titulo`, a palavra entre `*asteriscos*` vira a ênfase em serifa itálica.

## Componentes

| Grupo | Componente | Classe CSS | React | Variações |
|---|---|---|---|---|
| Marca | Logo | — | `Logo` | principal · redução · compacta · favicon · mono |
| Posts | Cursor "gre" | `.gfd-cursor--{cor}` | `CursorGre` | raiz · neon · azul · rosa (seta e etiqueta na mesma cor; contorno e texto em Papel de Algodão) |
| Posts | Tag | `.gfd-tag--{cor}` | `Tag` | neon · raiz · creme |
| Posts | Botão CTA | `.gfd-botao` | `Botao` | — |
| Posts | Título misto | `.gfd-titulo` (+ `em`) | `Titulo` | claro · escuro |
| Posts | Marca-texto neon | `.gfd-marca-texto` | `MarcaTexto` | — |
| Posts | Letras em degradê | `.gfd-degrade--{nome}` | `Degrade` | raiz-pulso · pulso-azul · raiz-pulso-azul · pulso-rosa · raiz-suave |
| Posts | Caixa de seleção | `.gfd-selecao` | `Selecao` | nome do arquivo + medida |
| Posts | Réguas | `.gfd-reguas` | `Reguas` | — |
| Posts | Moldura de post | `.gfd-post--{modo}` | `MolduraPost` | claro · escuro · neon · post 3:4 · reels 9:16 |
| Posts | Tecla 3D | `.gfd-tecla--{cor}` | `Tecla` | neon · creme · verde · preta · vidro |
| Posts | Card | `.gfd-card` | `Card` | — |
| Humor | Faixa de @ | `.gfd-faixa` | `FaixaArroba` | — |
| Humor | Texto adesivo | `.gfd-adesivo` | `TextoAdesivo` | simples · duplo |
| Humor | Cursor de comentário | `.gfd-comentario` | `Comentario` | — |
| Propostas | Slide 1280×720 | `.gfd-slide` | `Slide` | barra degradê + manchas verde · azul · rosa |
| Propostas | Cabeçalho | `.gfd-cabecalho` | `Cabecalho` | — |
| Propostas | Card de informação | `.gfd-info--{cor}` | `CardInfo` | rosa claro · azul claro · verde claro · branco · névoa |
| Propostas | Etapa | `.gfd-etapa--{cor}` | `Etapa` | verde 2 · rosa · neon · azul |
| Propostas | Card de lista | `.gfd-lista` | `CardLista` | — |
| Propostas | Card de preço | `.gfd-preco--{cor}` | `CardPreco` | rosa · raiz · neon |
| Propostas | Card de condição | `.gfd-condicao` | `CardCondicao` | — |

## Regras de uso
- No máximo **uma cor forte de destaque** por peça (neon, azul ou rosa).
- Duas fontes por peça: **Poppins** (posts) ou **Inter** (propostas) + **Instrument Serif itálica** na ênfase.
- Paleta oficial: Verde Raiz #0E4728 · Verde Pulso #35FF0D · Verde 2 #24A37D · Azul #0C8CE9 · Rosa #EE46D3 · Papel de Algodão #FFFCEE · Grafite #242424. Superfícies claras usam o tom 100 das próprias cores.
- Rosa é destaque raro. Azul é cor de interface (seleção, cursor).
- Mockups: Samsung Galaxy Book e Galaxy S26 Ultra (nunca MacBook/iPhone).

## Fontes
Poppins, Instrument Serif, Inter e Space Mono são carregadas do Google Fonts pelo `components.css`.
As fontes de display **Renamor**, **Tempting** e **Notebook** (usadas em alguns posts) não estão incluídas: instale-as à parte se for usar esses estilos.

## Origem
Valores extraídos do Figma "Grey Frame Design" (variáveis **GFD · Cores**, **GFD · Medidas**, estilos **GFD/Sombra** e **GFD/Degradê**).
