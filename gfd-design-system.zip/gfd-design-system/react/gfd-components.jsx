// GFD Design System · componentes React
// Uso: import "../tokens.css"; import "../css/components.css"; import { Titulo, Tag, ... } from "./gfd-components";
import React from "react";

const CURSOR_PATH = "M3 2.5 L20.5 9.6 L12.6 12.3 L9.6 20.3 Z";

export function CursorGre({ cor = "raiz", rotulo = "gre", preenchimento = "#111111" }) {
  return (
    <span className={`gfd-cursor gfd-cursor--${cor}`}>
      <svg viewBox="0 0 24 24" aria-hidden="true">
        <path d={CURSOR_PATH} fill={preenchimento} stroke="#fff" strokeWidth="1.6" strokeLinejoin="round" />
      </svg>
      <span className="gfd-cursor__tag">{rotulo}</span>
    </span>
  );
}

export const Tag = ({ cor = "neon", children }) => <span className={`gfd-tag gfd-tag--${cor}`}>{children}</span>;

export const Botao = ({ href, children = "Fale comigo · link na bio →", ...p }) =>
  href ? <a className="gfd-botao" href={href} {...p}>{children}</a> : <button className="gfd-botao" {...p}>{children}</button>;

/** Título misto: marque a palavra de ênfase com *asteriscos*. Ex.: "Autoridade não se *posta*." */
export function Titulo({ texto, escuro = false, as: Tag = "h2" }) {
  const partes = texto.split("*");
  return (
    <Tag className={`gfd-titulo${escuro ? " gfd-titulo--escuro" : ""}`}>
      {partes.map((p, i) => (i % 2 ? <em key={i}>{p}</em> : <React.Fragment key={i}>{p}</React.Fragment>))}
    </Tag>
  );
}

export const MarcaTexto = ({ children }) => <mark className="gfd-marca-texto">{children}</mark>;

/** degrade: raiz-pulso | pulso-azul | raiz-pulso-azul | pulso-rosa | raiz-suave */
export const Degrade = ({ degrade = "raiz-pulso", children }) => <span className={`gfd-degrade gfd-degrade--${degrade}`}>{children}</span>;

export function Selecao({ nome = "arquivo.png", largura, altura, children }) {
  return (
    <div className="gfd-selecao" data-nome={nome} style={{ width: largura, height: altura }}>
      {children}
      <i className="gfd-selecao__alca" /><i className="gfd-selecao__alca" /><i className="gfd-selecao__alca" /><i className="gfd-selecao__alca" />
      {largura && altura && <span className="gfd-selecao__medida">{largura} × {altura}</span>}
    </div>
  );
}

export const Reguas = ({ children }) => <div className="gfd-reguas">{children}</div>;

/** modo: claro | escuro | neon · formato: post | reels */
export function MolduraPost({ modo = "claro", formato = "post", numero = 1, children }) {
  const cursorCor = modo === "claro" ? "raiz" : "neon";
  return (
    <section className={`gfd-post gfd-post--${modo}${formato === "reels" ? " gfd-post--reels" : ""}`}>
      <div className="gfd-post__regua" />
      <div className="gfd-post__topo"><span>Grey Frame Design</span><span>GFD</span><span>Nº {String(numero).padStart(2, "0")}</span></div>
      {children}
      <div className="gfd-post__cursor"><CursorGre cor={cursorCor} /></div>
      <div className="gfd-post__linha" />
      <div className="gfd-post__rodape"><span>@greisyjordao</span><span>branding · marketing médico</span></div>
    </section>
  );
}

/** cor: neon | creme | verde | preta | vidro */
export const Tecla = ({ cor = "neon", children }) => (
  <span className={`gfd-tecla gfd-tecla--${cor}`}><span className="gfd-tecla__face">{children}</span></span>
);

export const Card = ({ numero, titulo, texto }) => (
  <article className="gfd-card">
    {numero && <span className="gfd-card__num">{numero}</span>}
    <h3 className="gfd-card__titulo">{titulo}</h3>
    {texto && <p className="gfd-card__texto">{texto}</p>}
  </article>
);

export const FaixaArroba = ({ perfis = ["@greisyjordao", "@gfd.mkt"], repeticoes = 4 }) => (
  <div className="gfd-faixa">{Array.from({ length: repeticoes }).flatMap((_, i) => perfis.map((p, j) => <span key={`${i}-${j}`}>{p}</span>))}</div>
);

export const TextoAdesivo = ({ duplo = false, children }) => <span className={`gfd-adesivo${duplo ? " gfd-adesivo--duplo" : ""}`}>{children}</span>;

export const Comentario = ({ children = "cliente: mas é só um logo" }) => (
  <span className="gfd-comentario">
    <svg width="28" height="28" viewBox="0 0 24 24"><path d={CURSOR_PATH} fill="#EE46D3" stroke="#fff" strokeWidth="1.6" /></svg>
    <span className="gfd-comentario__balao">{children}</span>
  </span>
);

/* ---------- Propostas e apresentações ---------- */
export const Slide = ({ children, manchas = true }) => (
  <section className="gfd-slide gfd-deck">
    <div className="gfd-slide__barra" />
    {manchas && <><div className="gfd-slide__mancha gfd-slide__mancha--verde" style={{ right: -160, top: -160 }} /><div className="gfd-slide__mancha gfd-slide__mancha--azul" style={{ left: -200, bottom: -220 }} /></>}
    <div style={{ position: "relative" }}>{children}</div>
    <div className="gfd-slide__rodape">Grey Frame Design</div>
  </section>
);

export const Cabecalho = ({ rotulo, titulo }) => (
  <header className="gfd-cabecalho"><p className="gfd-rotulo">{rotulo}</p><h2>{titulo}</h2></header>
);

/** cor: lilas | ceu | menta | branco | nevoa */
export const CardInfo = ({ cor = "lilas", rotulo, titulo, texto }) => (
  <article className={`gfd-info gfd-info--${cor}`}><p className="gfd-rotulo">{rotulo}</p><h3>{titulo}</h3><p>{texto}</p></article>
);

/** cor: verde-agua | rosa | neon | azul */
export const Etapa = ({ cor = "verde-agua", rotulo, titulo, texto }) => (
  <article className={`gfd-etapa gfd-etapa--${cor}`}>
    <div className="gfd-etapa__barra" />
    <div className="gfd-etapa__conteudo"><p className="gfd-rotulo">{rotulo}</p><h3>{titulo}</h3><p>{texto}</p></div>
  </article>
);

export const CardLista = ({ rotulo = "Incluído", itens = [] }) => (
  <article className="gfd-lista"><p className="gfd-rotulo">{rotulo}</p><ul>{itens.map((t) => <li key={t}>{t}</li>)}</ul></article>
);

/** cor: rosa | raiz | neon */
export const CardPreco = ({ cor = "rosa", rotulo = "Investimento de", valor, pacote }) => (
  <article className={`gfd-preco gfd-preco--${cor}`}><p className="gfd-rotulo">{rotulo}</p><strong>{valor}</strong><p>{pacote}</p></article>
);

export const CardCondicao = ({ titulo, texto }) => (
  <article className="gfd-condicao"><h3>{titulo}</h3><p>{texto}</p></article>
);

/* ---------- Logo ---------- */
/** versao: principal | reducao | compacta | favicon | mono · fundo: claro | escuro | preto | branco */
export function Logo({ versao = "principal", fundo = "claro", base = "/logos", ...p }) {
  const arquivo = versao === "favicon" ? "gfd-favicon.svg" : `gfd-logo-${versao}-${fundo}.svg`;
  return <img src={`${base}/${arquivo}`} alt="Grey Frame Design" {...p} />;
}
