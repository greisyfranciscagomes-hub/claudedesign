# Design Tokens · Grey Frame Design (GFD)

Tokens da identidade visual da Grey Frame Design: cores, espaçamento, raio de borda, sombras e fontes.
Os mesmos valores estão como variáveis no Figma (coleções **GFD · Cores** e **GFD · Medidas**) e como estilos de efeito **GFD/Sombra/…**.

## Arquivos

| Arquivo | Para quê |
|---|---|
| `tokens.json` | Fonte da verdade, no formato W3C Design Tokens (funciona com Style Dictionary e Tokens Studio) |
| `tokens.css` | Variáveis CSS prontas (`var(--gfd-verde-raiz-500)`) |
| `tailwind.gfd.js` | Extensão de tema para Tailwind CSS (`bg-gfd-verde-raiz-500`, `rounded-gfd-lg`) |

## Cores

Escala de 7 tons por cor: `900 · 800 · 700` (mais escuros) · `500` (base) · `300 · 200 · 100` (mais claros).

| Cor | Base | Papel |
|---|---|---|
| Verde Raiz | `#0E4728` | Principal |
| Verde Pulso | `#35FF0D` | Complementar (acento) |
| Azul Cursor | `#0C8CE9` | Terceira cor (interface) |
| Rosa | `#EE46D3` | Destaque raro |
| Papel de Algodão | `#FFFCEE` | Fundo |
| Grafite | `#242424` | Texto |

Regra: no máximo uma cor de destaque forte por peça.

## Superfícies (propostas e apresentações)

| Nome | HEX | Uso |
|---|---|---|
| Lilás | `#C5BCFF` | card de contexto |
| Céu | `#EAF5FF` | card de contexto |
| Menta | `#C8FCA0` | card de contexto |
| Névoa | `#F3F3F3` | fundo de etapa |
| Branco | `#FFFFFF` | cards de lista e condição |
| Tinta | `#0B0B0B` | texto dos slides |
| Verde-água | `#24A37D` | barra de etapa |

Tipografia de deck (slide 1280×720, fonte Inter): título 52 · título de card 26 · corpo 17 · item de lista 17 · rótulo 13 (caixa alta) · preço 56.
Cards: raio 16, padding 28, espaço entre cards 24.

## Espaçamento
`2xs 4` · `xs 8` · `sm 12` · `md 16` · `lg 24` · `xl 32` · `2xl 48` · `3xl 64` · `4xl 90` (px)

## Raio de borda
`xs 4` · `sm 6` · `md 8` · `lg 16` · `xl 24` · `pill 999` (px)

## Sombras
`sm` cursores e etiquetas · `md` cards · `lg` objetos flutuantes · `3d` teclas 3D · `brilho-neon` objetos neon

## Fontes
Poppins (títulos e texto) · Instrument Serif Italic (palavra de ênfase) · Space Mono (números e detalhes técnicos)

## Uso

```html
<link rel="stylesheet" href="tokens.css">
<button style="background: var(--gfd-verde-pulso-500); border-radius: var(--gfd-raio-pill); box-shadow: var(--gfd-sombra-sm);">Fale comigo</button>
```
